package controller;

import model.vo.Procedimento;

public class CadastroProcedimentoBO {

	public static String salvar(Procedimento procedimento) {
		return null;
		// TODO Auto-generated method stub
		
	}

}
