package controller;


public class ClienteControl {

	public static void salvar() {

	}

	public static boolean close() {
		return false;

	}

}
