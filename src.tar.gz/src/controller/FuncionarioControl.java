package controller;

public class FuncionarioControl {

	public static void salvar() {

	}

	public static boolean close() {
		return false;

	}

}
