package controller;

public class AgendamentoControl {

	public static void salvar() {

	}

	public static boolean close() {
		return false;

	}

}
